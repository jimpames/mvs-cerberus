# Cerberus Gate v2

**Algebraic MVS access perimeter** — a web auth front-end and TN3270 turret
for gatekeeping access to vintage mainframe stacks (TK5, VM/370 Sixpack,
and friends).

## What it does

Two parallel paths:

1. **Web auth path.** A user browses to the gate, sees the CERBERUS banner,
   enters credentials, and on success establishes a leased session.
2. **TN3270 turret path.** A 3270 emulator connects to the public port,
   sees a menu of available backend mainframes, and the gate splices the
   stream to the chosen backend (TK5 :3270, VM/370 Sixpack :3278, …).

The turret only runs while at least one authorized session is active.

## What's new in v2

| Concern | v1 | v2 |
|---|---|---|
| Auth backend | Windows LogonUser | RADIUS (pyrad), swappable to anything RADIUS-compatible |
| Config | Hard-coded constants + env vars | Self-describing INI with embedded schema |
| Storage | None (stateless) | SQLite users + bcrypt + audit log; swappable |
| Turret | Spawned per-session via ngrok | Long-lived `proxy3270` with multi-host menu |
| Admin | None | Schema-driven `/admin` dashboard |
| Target host | Windows | zLinux s390x ("our gatekeeper runs on a mainframe linux") |
| Structure | Two files | Algebraic — five typed interfaces with default impls |

## Algebraic decomposition

Six composable types. Each has an abstract base and a default concrete
implementation. Swapping an implementation is one config key, not a
code change.

```
AuthBackend                Storage              Turret               Exposure
├── RadiusClientAuth ←     ├── SqliteStorage ←  └── Proxy3270Turret ← ├── NgrokGoExposure ←
└── DirectStorageAuth      └── (yours here)         (yours here)      └── NoOpExposure

EmbeddedRadiusServer (pyrad, embedded; loopback by default)
GateManager (session lifecycle, ref-counts the Turret AND Exposure together)
```

The wiring is in `cerberus/__main__.py` — fewer than 100 lines that
compose all six from the config.

**Turret vs Exposure** are the LAN-side and WAN-side halves of the same
thing: Turret is the local TN3270 listener that routes to backends, and
Exposure is the public-facing tunnel that brings traffic from the
internet to the Turret. They come up together on first grant and tear
down together on last expire — when no one is authenticated, neither
the local TN3270 listener nor the public ngrok endpoint exists.

## Self-describing config

Every runtime section `[X]` has a sibling `[__schema__.X]` declaring its
keys, types, defaults, and descriptions. Field syntax is `type | default
| description`. The schema drives startup validation and the admin GUI.

Example excerpt:

```ini
[__schema__.auth]
__title__ = Authentication Backend
__description__ = Pluggable auth interface; default is RADIUS client
backend        = enum(radius,direct_sqlite) | radius | Which AuthBackend
radius_host    = host | 127.0.0.1 | RADIUS server address
radius_port    = port | 1812 | RADIUS server UDP port
radius_secret  = secret | | Shared secret with RADIUS server
radius_timeout = int(1,30) | 3 | RADIUS request timeout in seconds

[auth]
backend       = radius
radius_host   = 127.0.0.1
radius_port   = 1812
radius_secret = ${CERBERUS_RADIUS_SECRET}
radius_timeout = 3
```

Supported types: `str`, `int`, `int(min,max)`, `bool`, `host`, `port`,
`secret`, `enum(a,b,c)`, `path`. Values support `${ENV_VAR}` and
`${ENV_VAR:default}` references.

Adding a new field to the INI schema makes it appear in `/admin`
automatically — no template changes.

## Backend hosts (multi-instance sections)

Each backend mainframe is one `[host.NAME]` section:

```ini
[host.tk5]
display_name = MVS 3.8j TK5
description  = Turnkey MVS with TK5 updates
hostname     = 192.168.137.10
port         = 3270
protocol     = 3270

[host.sixpack]
display_name = VM/370 Community Sixpack
description  = VM/370 Sixpack edition
hostname     = 192.168.137.11
port         = 3278
protocol     = 3270
```

`proxy3270` reads these as menu entries; users pick one after connecting
their 3270 emulator.

## File layout

```
cerberus/
├── config/
│   └── cerberus.ini.example          # master config + embedded schema
├── cerberus/                          # the algebraic core (Python)
│   ├── __init__.py
│   ├── __main__.py                    # composes everything from config
│   ├── config.py                      # schema-aware INI loader
│   ├── storage.py                     # Storage ABC + SqliteStorage
│   ├── auth.py                        # AuthBackend ABC + RadiusClientAuth
│   ├── radius_dict.py                 # bundled RFC 2865 dictionary
│   ├── radius_server.py               # EmbeddedRadiusServer (pyrad)
│   ├── turret.py                      # Turret ABC + Proxy3270Turret
│   ├── exposure.py                    # Exposure ABC + NgrokGoExposure
│   ├── gate.py                        # GateManager (session lifecycle)
│   ├── web.py                         # Flask app
│   └── admin.py                       # schema-driven /admin GUI
├── cmd/
│   └── cerberus-tunnel/               # Go binary embedding ngrok-go v2
│       ├── main.go                    #   cross-compiles to s390x
│       ├── go.mod
│       └── README.md
├── templates/
│   ├── cerberus.html                  # CRT auth banner
│   ├── granted.html                   # post-auth: endpoint + host list
│   └── admin.html                     # schema-driven dashboard
├── static/
│   └── cerberus-banner.png            # Gemini-generated CERBERUS art
├── scripts/
│   ├── init_db.py                     # bootstrap SQLite + initial user
│   └── build_zlinux.md                # s390x deployment runbook
├── requirements.txt                   # Flask, waitress, pyrad, bcrypt
└── README.md
```

## Quick start

```bash
# 1. Install deps (Python 3.11+)
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# 2. Configure
cp config/cerberus.ini.example config/cerberus.ini
# Edit hostnames/ports for your backend mainframes.
# Set env vars:
export CERBERUS_RADIUS_SECRET=$(openssl rand -hex 32)
export CERBERUS_SECRET_KEY=$(openssl rand -hex 32)

# 3. Create the user DB and add an account
python scripts/init_db.py config/cerberus.ini

# 4. Build / install proxy3270 (see scripts/build_zlinux.md for s390x)
# For local testing: go install github.com/racingmars/proxy3270@latest

# 5. Run
python -m cerberus config/cerberus.ini
# Or for development:
python -m cerberus config/cerberus.ini --dev
```

Then browse to `http://127.0.0.1:5000/auth`. After auth, point your 3270
emulator at `127.0.0.1:3270` and pick a backend.

## RADIUS notes

By default Cerberus runs its own embedded pyrad server on UDP 1812
(loopback). It validates against the same SQLite users table. To use an
external RADIUS server instead (FreeRADIUS, Windows NPS, cloud RADIUS):

```ini
[radius_server]
enabled = false           # don't run the embedded daemon

[auth]
radius_host = 10.0.0.50   # your existing RADIUS server
radius_port = 1812
radius_secret = ${CERBERUS_RADIUS_SECRET}  # shared with that server
```

Same `AuthBackend` interface; same code path. The gate doesn't know or
care which RADIUS implementation is on the other end.

## Deployment

For the headline deployment target — **zLinux s390x running on Hercules
under VMware** — see `scripts/build_zlinux.md`. The gist:

- Cerberus is pure Python; runs natively on s390x
- `proxy3270` is Go; cross-compile with `GOARCH=s390x go build`
- bcrypt has a C extension; needs `build-essential python3-dev` for the
  s390x build
- Everything else (Flask, waitress, pyrad) is pure Python wheels

## License

GPL-3 (compatible with the proxy3270 license; aligns with Jim's other
GPL-3 work — MTOR / RENT-A-HAL).

## Acknowledgments

- **Matt Wilson** for `proxy3270` (github.com/racingmars/proxy3270)
- **Volker Bandke, Jürgen Winkelmann, Rob Prins** for TK5
- **The pyrad authors** for a clean Python RADIUS implementation
- **Gemini** for the three-headed-dog banner art
