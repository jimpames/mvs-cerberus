#!/bin/bash
#
# Cerberus bringup script — brings the whole stack up cold.
# Run after reboot, or whenever you've stopped everything.
# Idempotent: safe to run twice; it just won't re-start what's already up.
#
set -euo pipefail

CERB_HOME=/opt/cerberus
CERB_ENV=/etc/cerberus/environment
CERB_LOG=/var/log/cerberus.log
NGROK_LOG=/var/log/ngrok.log
CERB_PORT="${CERBERUS_PORT:-1812}"   # default RADIUS port; override in env

echo "=== Cerberus bringup $(date) ==="

# 1. Confirm we can read the environment file before doing anything else.
if [[ ! -r "$CERB_ENV" ]]; then
  echo "FATAL: cannot read $CERB_ENV — is it owned correctly? (try sudo)"
  exit 1
fi

# 2. Load it into this shell. set -a marks every var auto-export.
set -a
# shellcheck disable=SC1090
source "$CERB_ENV"
set +a

# 3. Sanity check: the variables we *need* must be non-empty.
for var in CERBERUS_RADIUS_SECRET CERBERUS_SECRET_KEY NGROK_AUTHTOKEN; do
  if [[ -z "${!var:-}" ]]; then
    echo "FATAL: $var is not set in $CERB_ENV"
    exit 1
  fi
done

# 4. Activate the venv.
if [[ ! -f "$CERB_HOME/venv/bin/activate" ]]; then
  echo "FATAL: venv not found at $CERB_HOME/venv"
  exit 1
fi
# shellcheck disable=SC1091
source "$CERB_HOME/venv/bin/activate"

# 5. Start ngrok in the background if not already running.
if pgrep -x ngrok >/dev/null; then
  echo "ngrok already running, skipping."
else
  echo "Starting ngrok..."
  nohup ngrok http "$CERB_PORT" --log=stdout > "$NGROK_LOG" 2>&1 &
  sleep 3   # let ngrok bind and register the tunnel
  echo "ngrok started, log at $NGROK_LOG"
fi

# 6. Start cerberus in the background.
if pgrep -f "python -m cerberus" >/dev/null; then
  echo "cerberus already running, skipping."
else
  echo "Starting cerberus..."
  cd "$CERB_HOME"
  nohup python -m cerberus > "$CERB_LOG" 2>&1 &
  echo "cerberus started, log at $CERB_LOG"
fi

# 7. Brief delay then sanity check.
sleep 2
if pgrep -f "python -m cerberus" >/dev/null; then
  echo "=== Bringup complete. Cerberus is running. ==="
  echo "Logs: $CERB_LOG"
  echo "ngrok logs: $NGROK_LOG"
  echo "Tail logs with: tail -f $CERB_LOG"
else
  echo "=== Bringup FAILED — cerberus exited. Check $CERB_LOG ==="
  tail -20 "$CERB_LOG"
  exit 1
fi
