#!/bin/bash
#
# Cerberus master bringup — brings the whole stack up cold.
# Delegates to existing scripts/binaries where they exist.
#
set -euo pipefail

CERB_HOME=/opt/cerberus
CERB_ENV=/etc/cerberus/environment
CERB_LOG=/var/log/cerberus.log
TUNNELS_SCRIPT=/opt/cerberus/scripts/cerberus-tunnels.sh

echo "=== Cerberus bringup $(date) ==="

# Kill anything stale first
pkill -f "python -m cerberus" 2>/dev/null || true
/opt/cerberus/scripts/cerberus-tunnels.sh stop
sleep 2

# 1. Environment file readable.
[[ -r "$CERB_ENV" ]] || { echo "FATAL: cannot read $CERB_ENV"; exit 1; }

# 2. Load env, auto-export.
set -a
# shellcheck disable=SC1090
source "$CERB_ENV"
set +a

# 3. Sanity-check required vars.
for var in CERBERUS_RADIUS_SECRET CERBERUS_SECRET_KEY NGROK_AUTHTOKEN; do
  if [[ -z "${!var:-}" ]]; then
    echo "FATAL: $var is not set in $CERB_ENV"; exit 1
  fi
done

# 4. Activate venv.
[[ -f "$CERB_HOME/venv/bin/activate" ]] || { echo "FATAL: venv missing"; exit 1; }
# shellcheck disable=SC1091
source "$CERB_HOME/venv/bin/activate"

# 5. Start cerberus first — its ports must be listening before tunnels register.
if pgrep -f "python -m cerberus" >/dev/null; then
  echo "cerberus already running, skipping."
else
  echo "Starting cerberus..."
  cd "$CERB_HOME"
  nohup python -m cerberus > "$CERB_LOG" 2>&1 &
  sleep 3
fi

# 6. Start tunnels via existing script — HTTPS + TCP.
if [[ -x "$TUNNELS_SCRIPT" ]]; then
  echo "Starting tunnels (HTTPS + TCP)..."
  "$TUNNELS_SCRIPT" start 
else
  echo "FATAL: $TUNNELS_SCRIPT not found or not executable"; exit 1
fi

# 7. Status summary.
echo ""
echo "=== Status ==="
pgrep -fa "python -m cerberus" >/dev/null && echo "  cerberus:    RUNNING" || echo "  cerberus:    NOT RUNNING"
"$TUNNELS_SCRIPT" status

echo ""
echo "Endpoints:"
echo "  Web:    https://auth.tso3270.com   (→ 127.0.0.1:5000)"
echo "  TN3270: tso.tso3270.com:26640      (→ 127.0.0.1:3270, via 7.tcp.ngrok.io:26640)"
echo ""
echo "=== Bringup complete ==="
