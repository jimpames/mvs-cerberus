# Deploying Cerberus to zLinux s390x

The headline: **the gatekeeper runs on a mainframe Linux**. Cerberus is
deployed on the zubuntu zLinux s390x VM running on Hercules, in front of
the TK5 and Sixpack TN3270 listeners. Everything in Cerberus is pure
Python except `proxy3270`, which is Go and cross-compiles cleanly to
s390x.

## What you need on the zLinux box

```
zubuntu (s390x)
├── Python 3.11+         (apt install python3 python3-pip python3-venv)
├── Go 1.21+             (only on your build box; not required on s390x)
├── proxy3270            (cross-compiled or built locally on s390x)
└── Cerberus tree        (this repo)
```

## 1. Build `proxy3270` for s390x

You can do this either on the s390x box itself (slower but simpler) or
cross-compile from an amd64 build host.

### Option A — Native build on zLinux

```bash
# On the zubuntu zLinux VM
sudo apt install golang-go git
mkdir -p ~/build && cd ~/build
git clone https://github.com/racingmars/proxy3270
cd proxy3270
go build -o proxy3270
sudo install -m 0755 proxy3270 /usr/local/bin/proxy3270
```

### Option B — Cross-compile from amd64 (Windows 11 dev box)

```powershell
# On your Windows dev box with Go installed
git clone https://github.com/racingmars/proxy3270
cd proxy3270
$env:GOOS="linux"; $env:GOARCH="s390x"
go build -o proxy3270-s390x
```

Then copy `proxy3270-s390x` to the zLinux VM and install it as
`/usr/local/bin/proxy3270`. Verify:

```bash
zubuntu@zlinux:~$ file /usr/local/bin/proxy3270
/usr/local/bin/proxy3270: ELF 64-bit MSB executable, IBM S/390, ...
zubuntu@zlinux:~$ /usr/local/bin/proxy3270 -h
```

## 2. Build `cerberus-tunnel` for s390x

The ngrok agent doesn't ship an s390x binary, but `golang.ngrok.com/ngrok/v2`
is open-source pure Go and cross-compiles to any platform Go supports.
The Cerberus repo ships a small Go program in `cmd/cerberus-tunnel/`
that embeds ngrok-go to hold the public TCP endpoint.

### Native build on zLinux

```bash
cd /opt/cerberus/cmd/cerberus-tunnel
go mod tidy
go build -o cerberus-tunnel
sudo install -m 0755 cerberus-tunnel /usr/local/bin/cerberus-tunnel
```

### Cross-compile from amd64

```bash
cd cerberus/cmd/cerberus-tunnel
go mod tidy
GOOS=linux GOARCH=s390x go build -o cerberus-tunnel-s390x
file cerberus-tunnel-s390x
# ELF 64-bit MSB executable, IBM S/390 ...
```

Smoke-test it on the zLinux box before integrating with Cerberus:

```bash
export NGROK_AUTHTOKEN=2your_token_here
/usr/local/bin/cerberus-tunnel --upstream 127.0.0.1:22 \
                                --remote-url tcp://
# Should print: tunnel established: tcp://N.tcp.ngrok.io:NNNNN -> 127.0.0.1:22
# Try ssh to that address from another host; ctrl-C to tear down.
```

## 3. Install Cerberus

```bash
# On the zLinux VM
sudo mkdir -p /opt/cerberus /etc/cerberus /var/lib/cerberus
sudo chown $USER /opt/cerberus /etc/cerberus /var/lib/cerberus

# Copy the cerberus/ tree from your dev box (rsync, scp, git pull, whatever)
cd /opt/cerberus

# Create the venv and install
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Both `bcrypt` and `pyrad` build cleanly on s390x — `bcrypt` has a C
extension that compiles from source if no wheel is available, so make
sure `build-essential` and `python3-dev` are installed:

```bash
sudo apt install build-essential python3-dev libffi-dev
```

## 4. Configure

```bash
cp config/cerberus.ini.example /etc/cerberus/cerberus.ini
# Edit the file:
#   - [gate].public_hostname        → tso3270.com (or your CNAME)
#   - [host.tk5].hostname           → IP of the TK5 Hercules host
#   - [host.sixpack].hostname       → IP of the VM/370 Sixpack host
#   - [turret].binary_path          → /usr/local/bin/proxy3270
```

Set the shared secret — used by both the embedded RADIUS server and the
auth client (which talk to each other over loopback) — plus the ngrok
authtoken used by `cerberus-tunnel`:

```bash
# /etc/cerberus/environment
CERBERUS_RADIUS_SECRET=<long-random-string>
CERBERUS_SECRET_KEY=<long-random-string-for-flask>
NGROK_AUTHTOKEN=<your-ngrok-authtoken>
```

Generate the first two with `openssl rand -hex 32` and paste them in.
Get the ngrok authtoken from your ngrok dashboard.

## 5. Bootstrap the user DB

```bash
cd /opt/cerberus
source venv/bin/activate
export $(cat /etc/cerberus/environment | xargs)
python scripts/init_db.py /etc/cerberus/cerberus.ini
# Prompts for username + password for the initial account
```

## 6. systemd unit

`/etc/systemd/system/cerberus-gate.service`:

```ini
[Unit]
Description=Cerberus Gate — MVS access perimeter
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=cerberus
Group=cerberus
WorkingDirectory=/opt/cerberus
EnvironmentFile=/etc/cerberus/environment
ExecStart=/opt/cerberus/venv/bin/python -m cerberus /etc/cerberus/cerberus.ini
Restart=on-failure
RestartSec=3
# Hardening (loosen as needed)
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/var/lib/cerberus

[Install]
WantedBy=multi-user.target
```

Then:

```bash
sudo useradd -r -d /opt/cerberus -s /usr/sbin/nologin cerberus
sudo chown -R cerberus:cerberus /var/lib/cerberus /opt/cerberus
sudo chmod 0600 /etc/cerberus/environment
sudo systemctl daemon-reload
sudo systemctl enable --now cerberus-gate
sudo journalctl -u cerberus-gate -f
```

## 7. Network considerations on zLinux

With the embedded `cerberus-tunnel` doing outbound to ngrok, the zLinux
VM no longer needs **any** inbound public ports. The tunnel is dialed
out from inside, the same way the standalone ngrok agent did. This is
materially better than running a public TCP listener:

| Port  | Bind     | Purpose | Public? |
|-------|----------|---------|---------|
| 5000  | 127.0.0.1 | Flask auth banner | No (front with nginx/Caddy for TLS) |
| 3270  | 127.0.0.1 | proxy3270 turret | **No** — only reachable via ngrok tunnel |
| 1812  | 127.0.0.1 | RADIUS, loopback only | No |
| (egress 443) | — | ngrok tunnel outbound | Yes, outbound TCP |

The public face of the gate is the HTTPS auth banner — front Flask with
nginx or Caddy on the same host for TLS termination. The TN3270 side is
reached via the ngrok TCP endpoint that `cerberus-tunnel` holds during
authorized session windows.

## 8. Verify

From your workstation:

```bash
# Auth banner
curl -k https://tso3270.com/auth
# Should return the CRT/banner HTML

# TN3270 menu (after auth grants a session)
qws3270 → tso3270.com:3270
# Should show the proxy3270 host-selection menu
```

## 9. The story

> "Our gatekeeper runs on a mainframe Linux."

Cerberus is Python (pyrad for RADIUS, Flask for the gate, bcrypt for
hashing) plus two Go binaries (`proxy3270` for the TN3270 turret,
`cerberus-tunnel` for the ngrok ingress). Every piece runs natively on
s390x:

- `bcrypt`, `pyrad`, `Flask`, `waitress` — pure Python wheels
- `proxy3270` — cross-compiles with `GOARCH=s390x go build`
- `cerberus-tunnel` — same, using `golang.ngrok.com/ngrok/v2`

The auth chain (Flask → pyrad RADIUS server → SQLite) runs entirely on
the IBM S/390 architecture emulated by Hercules. The ngrok tunnel that
makes the gate publicly reachable runs **in the same address space, on
the same emulated mainframe**, holding the existing reserved TCP address
at `tso.tso3270.com:26640`. No Windows box, no amd64 shim, no compromise.

The CERBERUS three-headed-dog banner, the auth state, the user database,
the audit log, the RADIUS daemon, the TN3270 turret, and the public
endpoint that exposes it — all of it on zLinux. The same hardware
lineage as the MVS instance it's protecting.
