#!/usr/bin/env python3
"""
init_db.py — bootstrap the Cerberus user database.

Reads cerberus.ini to find the storage DSN, creates the SQLite schema if
needed, and prompts for an initial user. Safe to re-run — won't duplicate
existing users.

Usage:
  python scripts/init_db.py                          # uses ./config/cerberus.ini
  python scripts/init_db.py /etc/cerberus/cerberus.ini
"""

import argparse
import getpass
import os
import sys
from pathlib import Path

# Allow running from the repo root or scripts/ subdirectory
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from cerberus.config import load as load_config  # noqa: E402
from cerberus.storage import build_storage         # noqa: E402


def main():
    parser = argparse.ArgumentParser(description="Bootstrap the Cerberus DB")
    parser.add_argument("config", nargs="?", default="config/cerberus.ini")
    parser.add_argument("--user", help="Username for initial account (prompted if omitted)")
    parser.add_argument("--password", help="Password (prompted if omitted; --password is insecure)")
    args = parser.parse_args()

    cfg_path = Path(args.config)
    if not cfg_path.exists():
        print(f"Config not found: {cfg_path}")
        print("Copy config/cerberus.ini.example → config/cerberus.ini and edit first.")
        return 2

    cfg = load_config(cfg_path)
    storage = build_storage(cfg.section("storage"))
    print(f"Storage initialized: {cfg.section('storage')['dsn']}")

    existing = storage.list_users()
    if existing:
        print(f"DB already has {len(existing)} user(s):")
        for u in existing:
            mark = " " if u.enabled else "x"
            print(f"  [{mark}] {u.username}  (created {u.created_at}, last_logon {u.last_logon or 'never'})")
        print()
        ans = input("Add another user? [y/N] ").strip().lower()
        if ans != "y":
            return 0

    username = args.user or input("Username: ").strip()
    if not username:
        print("Empty username — aborting.")
        return 1

    if args.password:
        password = args.password
    else:
        password = getpass.getpass("Password: ")
        confirm = getpass.getpass("Confirm:  ")
        if password != confirm:
            print("Passwords don't match — aborting.")
            return 1
        if len(password) < 8:
            print("Password must be at least 8 characters — aborting.")
            return 1

    try:
        storage.add_user(username, password, enabled=True)
    except Exception as e:
        print(f"Failed to add user: {e}")
        return 1

    storage.log_event("admin.bootstrap_user", username, client_ip="(init_db)")
    print(f"\nUser {username!r} created and enabled.")
    print("\nRADIUS shared secret reminder:")
    print(f"  Set CERBERUS_RADIUS_SECRET in the environment before starting cerberus.")
    print(f"  Both auth.radius_secret and radius_server.secret must resolve to the same value.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
