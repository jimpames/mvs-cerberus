#!/bin/bash
# cerberus-tunnels — bring up the persistent HTTPS gate tunnel
# (and optionally a long-lived TCP sentinel tunnel) outside Cerberus's
# per-session exposure management.
#
# Usage:
#   cerberus-tunnels.sh start         # start HTTPS tunnel (default)
#   cerberus-tunnels.sh start --tcp   # start both HTTPS and TCP sentinel
#   cerberus-tunnels.sh stop          # stop both
#   cerberus-tunnels.sh status        # show what's running

set -u

ENV_FILE=/etc/cerberus/environment
TUNNEL_BIN=/usr/local/bin/cerberus-tunnel
RUN_DIR=/var/run/cerberus
LOG_DIR=/var/log/cerberus

HTTPS_URL="https://auth.tso3270.com"
HTTPS_UPSTREAM="127.0.0.1:5000"
HTTPS_PID="$RUN_DIR/https-tunnel.pid"
HTTPS_LOG="$LOG_DIR/https-tunnel.log"

TCP_URL="tcp://7.tcp.ngrok.io:26640"
TCP_UPSTREAM="127.0.0.1:3270"
TCP_PID="$RUN_DIR/tcp-tunnel.pid"
TCP_LOG="$LOG_DIR/tcp-tunnel.log"

# ----- helpers ---------------------------------------------------------------

ensure_dirs() {
    sudo mkdir -p "$RUN_DIR" "$LOG_DIR"
    sudo chown "$USER:$USER" "$RUN_DIR" "$LOG_DIR"
}

load_env() {
    if [[ ! -r "$ENV_FILE" ]]; then
        echo "Cannot read $ENV_FILE (try: sudo chown $USER $ENV_FILE)" >&2
        exit 1
    fi
    set -a
    source "$ENV_FILE"
    set +a
    if [[ -z "${NGROK_AUTHTOKEN:-}" ]]; then
        echo "NGROK_AUTHTOKEN not set in $ENV_FILE" >&2
        exit 1
    fi
}

is_alive() {
    local pid_file="$1"
    [[ -f "$pid_file" ]] && kill -0 "$(cat "$pid_file")" 2>/dev/null
}

start_tunnel() {
    local name="$1" url="$2" upstream="$3" pid_file="$4" log_file="$5"
    if is_alive "$pid_file"; then
        echo "[$name] already running (pid=$(cat "$pid_file"))"
        return 0
    fi
    echo "[$name] starting: $url -> $upstream"
    nohup "$TUNNEL_BIN" \
        --upstream "$upstream" \
        --remote-url "$url" \
        > "$log_file" 2>&1 &
    echo $! > "$pid_file"
    sleep 2
    if is_alive "$pid_file"; then
        echo "[$name] up (pid=$(cat "$pid_file"), log=$log_file)"
    else
        echo "[$name] FAILED to start — check $log_file"
        tail -5 "$log_file"
        rm -f "$pid_file"
        return 1
    fi
}

stop_tunnel() {
    local name="$1" pid_file="$2"
    if [[ ! -f "$pid_file" ]]; then
        echo "[$name] not running (no pid file)"
        return 0
    fi
    local pid
    pid="$(cat "$pid_file")"
    if kill -0 "$pid" 2>/dev/null; then
        echo "[$name] stopping pid=$pid"
        kill "$pid"
        sleep 1
        kill -9 "$pid" 2>/dev/null || true
    fi
    rm -f "$pid_file"
}

status_tunnel() {
    local name="$1" pid_file="$2" url="$3"
    if is_alive "$pid_file"; then
        echo "[$name] RUNNING pid=$(cat "$pid_file")  url=$url"
    else
        echo "[$name] stopped"
    fi
}

# ----- main ------------------------------------------------------------------

cmd="${1:-status}"
opt="${2:-}"

case "$cmd" in
    start)
        ensure_dirs
        load_env
        start_tunnel "HTTPS" "$HTTPS_URL" "$HTTPS_UPSTREAM" "$HTTPS_PID" "$HTTPS_LOG"
        if [[ "$opt" == "--tcp" ]]; then
            start_tunnel "TCP" "$TCP_URL" "$TCP_UPSTREAM" "$TCP_PID" "$TCP_LOG"
        fi
        ;;
    stop)
        stop_tunnel "HTTPS" "$HTTPS_PID"
        stop_tunnel "TCP" "$TCP_PID"
        ;;
    status)
        status_tunnel "HTTPS" "$HTTPS_PID" "$HTTPS_URL"
        status_tunnel "TCP" "$TCP_PID" "$TCP_URL"
        ;;
    restart)
        "$0" stop
        sleep 1
        "$0" start "$opt"
        ;;
    *)
        echo "Usage: $0 {start [--tcp]|stop|status|restart}"
        exit 1
        ;;
esac
