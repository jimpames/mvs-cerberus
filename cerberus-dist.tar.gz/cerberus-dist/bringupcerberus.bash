python -m cerberus /etc/cerberus/cerberus.ini --dev 2>&1 | tee /tmp/gate.log
