"""
cerberus.turret — the interior TN3270 proxy.

The Turret is what 3270 emulators actually connect to. It presents a menu
of available backend mainframes (drawn from [host.*] config sections) and
splices the user's TN3270 stream to whichever backend they select.

Default implementation: proxy3270 (Matt Wilson's Go TN3270 reverse proxy).
The abstraction is here so a pure-Python or alternative Go implementation
can be dropped in without touching the rest of Cerberus.
"""

from __future__ import annotations

import json
import logging
import os
import signal
import socket
import subprocess
import threading
import time
from abc import ABC, abstractmethod
from contextlib import suppress
from pathlib import Path
from typing import Optional

log = logging.getLogger("cerberus.turret")


# ─── Abstract Turret ─────────────────────────────────────────────────────────

class Turret(ABC):
    """The interface every concrete TN3270 turret must satisfy."""

    @abstractmethod
    def start(self) -> None: ...
    @abstractmethod
    def stop(self) -> None: ...
    @abstractmethod
    def is_running(self) -> bool: ...
    @abstractmethod
    def reload_hosts(self, hosts: dict[str, dict]) -> None: ...


# ─── proxy3270 driver ────────────────────────────────────────────────────────

class Proxy3270Turret(Turret):
    """Manages a long-lived proxy3270 subprocess.

    proxy3270 reads its host list from a JSON config file at startup. To
    change the host list we rewrite the file and restart the process — it
    does not support live reload, but restart is sub-second.
    """

    def __init__(
        self,
        binary_path: str,
        config_path: str,
        listen_addr: str,
        listen_port: int,
        hosts: dict[str, dict],
        unnegotiate: bool = False,
    ):
        self.binary_path = binary_path
        self.config_path = config_path
        self.listen_addr = listen_addr
        self.listen_port = listen_port
        self.hosts = hosts
        self.unnegotiate = unnegotiate
        self._proc: Optional[subprocess.Popen] = None
        self._lock = threading.RLock()

    # ── lifecycle ────────────────────────────────────────────────────────────

    def start(self) -> None:
        with self._lock:
            if self._proc and self._proc.poll() is None:
                log.debug("proxy3270 already running (pid=%d)", self._proc.pid)
                return
            self._write_config()
            self._spawn()

    def stop(self) -> None:
        with self._lock:
            if not self._proc:
                return
            if self._proc.poll() is None:
                log.info("Stopping proxy3270 pid=%d", self._proc.pid)
                with suppress(Exception):
                    if os.name == "nt":
                        self._proc.terminate()
                    else:
                        self._proc.send_signal(signal.SIGTERM)
                try:
                    self._proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self._proc.kill()
            self._proc = None

    def is_running(self) -> bool:
        with self._lock:
            return self._proc is not None and self._proc.poll() is None

    def reload_hosts(self, hosts: dict[str, dict]) -> None:
        """Rewrite config and bounce the process."""
        with self._lock:
            self.hosts = hosts
            was_running = self.is_running()
            if was_running:
                self.stop()
            if was_running:
                self.start()

    # ── internals ────────────────────────────────────────────────────────────

    def _write_config(self) -> None:
        cfg = {
            "title": "CERBERUS GATE",
            "disclaimer": "Authenticated session. All activity logged.",
            "servers": [
                {
                    "name": h["display_name"],
                    "host": h["hostname"],
                    "port": h["port"],
                }
                for h in self.hosts.values()
            ],
        }
        path = Path(self.config_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(cfg, indent=2))
        log.info("Wrote proxy3270 config to %s with %d host(s)", path, len(cfg["servers"]))

    def _spawn(self) -> None:
        if not Path(self.binary_path).exists():
            raise FileNotFoundError(
                f"proxy3270 binary not found at {self.binary_path}. "
                f"Build with: GOARCH=s390x go build -o {self.binary_path} "
                f"github.com/racingmars/proxy3270"
            )
        argv = [self.binary_path, "-config", self.config_path]
        if self.unnegotiate:
            argv.append("-unnegotiate")
        log.info("Spawning: %s", " ".join(argv))
        self._proc = subprocess.Popen(
            argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        # Quick liveness probe — wait up to 3s for the port to accept
        deadline = time.time() + 3
        while time.time() < deadline:
            with suppress(OSError):
                with socket.create_connection(
                    ("127.0.0.1" if self.listen_addr == "0.0.0.0" else self.listen_addr,
                     self.listen_port),
                    timeout=0.5,
                ):
                    log.info("proxy3270 listening on %s:%d", self.listen_addr, self.listen_port)
                    return
            time.sleep(0.2)
        log.warning(
            "proxy3270 did not begin listening within 3s; check stderr from pid=%d",
            self._proc.pid,
        )


# ─── Factory ─────────────────────────────────────────────────────────────────

def build_turret(turret_cfg: dict, host_cfgs: dict[str, dict]) -> Turret:
    backend = turret_cfg.get("backend", "proxy3270")
    if backend == "proxy3270":
        return Proxy3270Turret(
            binary_path=turret_cfg["binary_path"],
            config_path=turret_cfg["config_path"],
            listen_addr=turret_cfg["listen_addr"],
            listen_port=turret_cfg["listen_port"],
            hosts=host_cfgs,
            unnegotiate=turret_cfg.get("unnegotiate", False),
        )
    raise ValueError(f"Unsupported turret backend: {backend}")
