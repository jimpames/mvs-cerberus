"""
cerberus.exposure — public-facing tunnel abstraction.

Conceptually, this is the WAN-side counterpart to the Turret:

    Turret    — LAN-side TN3270 listener routing to backend mainframes
    Exposure  — WAN-side tunnel bringing public traffic to the Turret

They are managed in lockstep by the Gate: both come up on first grant,
both go down after the last expire. The TN3270 listener exists locally
when sessions are active; the public TCP endpoint exists upstream when
sessions are active. Outside of that window, neither exists.

Default implementation: NgrokGoExposure spawns the ./cmd/cerberus-tunnel
Go binary, which uses golang.ngrok.com/ngrok/v2 to hold a TCP endpoint
at a reserved ngrok address. The binary cross-compiles to s390x.

Alternative: NoOpExposure for when you front Cerberus with nginx/Caddy
yourself and don't need a tunnel. Or when you're behind a proper firewall
and exposing the proxy3270 port directly.
"""

from __future__ import annotations

import json
import logging
import os
import signal
import socket
import subprocess
import threading
import time
from abc import ABC, abstractmethod
from contextlib import suppress
from pathlib import Path
from typing import Optional

log = logging.getLogger("cerberus.exposure")


# ─── Abstract Exposure ───────────────────────────────────────────────────────

class Exposure(ABC):
    """The interface every public-endpoint exposer must satisfy."""

    @abstractmethod
    def start(self) -> None: ...
    @abstractmethod
    def stop(self) -> None: ...
    @abstractmethod
    def is_running(self) -> bool: ...
    @abstractmethod
    def public_url(self) -> Optional[str]: ...


# ─── NgrokGoExposure ─────────────────────────────────────────────────────────

class NgrokGoExposure(Exposure):
    """Spawns the cerberus-tunnel Go binary which embeds ngrok-go v2."""

    def __init__(
        self,
        binary_path: str,
        upstream_addr: str,
        upstream_port: int,
        remote_url: str,
        authtoken_env: str = "NGROK_AUTHTOKEN",
    ):
        self.binary_path = binary_path
        self.upstream = f"{upstream_addr}:{upstream_port}"
        self.remote_url = remote_url
        self.authtoken_env = authtoken_env

        self._proc: Optional[subprocess.Popen] = None
        self._public_url: Optional[str] = None
        self._lock = threading.RLock()
        self._reader_thread: Optional[threading.Thread] = None

    def start(self) -> None:
        with self._lock:
            if self._proc and self._proc.poll() is None:
                log.debug("cerberus-tunnel already running (pid=%d)", self._proc.pid)
                return
            if not Path(self.binary_path).exists():
                raise FileNotFoundError(
                    f"cerberus-tunnel binary not found at {self.binary_path}. "
                    f"Build with: cd cmd/cerberus-tunnel && "
                    f"GOOS=linux GOARCH=s390x go build -o {self.binary_path}"
                )
            if not os.environ.get(self.authtoken_env):
                raise RuntimeError(
                    f"{self.authtoken_env} env var not set; cerberus-tunnel cannot authenticate"
                )

            argv = [
                self.binary_path,
                "--upstream", self.upstream,
                "--remote-url", self.remote_url,
                "--json-status",
            ]
            log.info("Spawning: %s", " ".join(argv))
            # Note: we INHERIT the env, so NGROK_AUTHTOKEN propagates to the child
            self._proc = subprocess.Popen(
                argv,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            self._public_url = None
            self._reader_thread = threading.Thread(
                target=self._read_status,
                daemon=True,
                name="cerberus-tunnel-reader",
            )
            self._reader_thread.start()

            # Wait up to 10s for tunnel-up notification on stdout
            deadline = time.time() + 10
            while time.time() < deadline:
                if self._public_url:
                    log.info(
                        "Tunnel up: %s -> %s (pid=%d)",
                        self._public_url, self.upstream, self._proc.pid,
                    )
                    return
                if self._proc.poll() is not None:
                    err = self._proc.stderr.read().decode("utf-8", errors="replace")
                    raise RuntimeError(f"cerberus-tunnel exited early: {err}")
                time.sleep(0.2)
            log.warning("cerberus-tunnel did not report ready within 10s")

    def stop(self) -> None:
        with self._lock:
            if not self._proc:
                return
            if self._proc.poll() is None:
                log.info("Stopping cerberus-tunnel pid=%d", self._proc.pid)
                with suppress(Exception):
                    self._proc.send_signal(signal.SIGTERM)
                try:
                    self._proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    log.warning("cerberus-tunnel didn't exit in 5s; killing")
                    self._proc.kill()
                    self._proc.wait(timeout=2)
            self._proc = None
            self._public_url = None

    def is_running(self) -> bool:
        with self._lock:
            return self._proc is not None and self._proc.poll() is None

    def public_url(self) -> Optional[str]:
        with self._lock:
            return self._public_url

    def _read_status(self) -> None:
        """Background reader: parses the first JSON line from stdout to pick
        up the public URL, then logs subsequent output as-is."""
        if not self._proc or not self._proc.stdout:
            return
        first_line = True
        try:
            for line in iter(self._proc.stdout.readline, b""):
                decoded = line.decode("utf-8", errors="replace").rstrip()
                if first_line and decoded.startswith("{"):
                    try:
                        msg = json.loads(decoded)
                        self._public_url = msg.get("url")
                        first_line = False
                        continue
                    except json.JSONDecodeError:
                        pass
                first_line = False
                if decoded:
                    log.info("[tunnel] %s", decoded)
        except Exception as e:
            log.debug("Tunnel reader thread exiting: %s", e)


# ─── NoOpExposure ────────────────────────────────────────────────────────────

class NoOpExposure(Exposure):
    """Does nothing. For setups where you front Cerberus with your own
    reverse proxy or expose the turret port directly."""

    def start(self) -> None:
        log.info("Exposure: no-op (no tunnel managed by Cerberus)")

    def stop(self) -> None:
        pass

    def is_running(self) -> bool:
        return True  # The "no tunnel" state is always trivially "running"

    def public_url(self) -> Optional[str]:
        return None


# ─── Factory ─────────────────────────────────────────────────────────────────

def build_exposure(cfg: dict) -> Exposure:
    backend = cfg.get("backend", "ngrok_go")
    if backend == "ngrok_go":
        return NgrokGoExposure(
            binary_path=cfg["binary_path"],
            upstream_addr=cfg["upstream_addr"],
            upstream_port=cfg["upstream_port"],
            remote_url=cfg["remote_url"],
            authtoken_env=cfg.get("authtoken_env", "NGROK_AUTHTOKEN"),
        )
    if backend == "none":
        return NoOpExposure()
    raise ValueError(f"Unsupported exposure backend: {backend}")
