#!/bin/bash
# Cerberus Gate v2 - First Time Setup Script

set -e

echo "=== Cerberus Gate v2 Setup ==="

# Create directories
sudo mkdir -p /etc/cerberus
sudo mkdir -p /var/log/cerberus

# Copy configs if missing
if [ ! -f /etc/cerberus/cerberus.ini ]; then
    sudo cp etc-cerberus-example/cerberus.ini /etc/cerberus/
    echo "✓ Created /etc/cerberus/cerberus.ini"
fi

if [ ! -f /etc/cerberus/environment ]; then
    sudo cp etc-cerberus-example/environment /etc/cerberus/environment
    echo "✓ Created /etc/cerberus/environment from template"
    echo "   → IMPORTANT: Edit with your own secrets!"
fi

# Set permissions
sudo chown -R cerberus:cerberus /etc/cerberus 2>/dev/null || true
sudo chown -R cerberus:cerberus /opt/cerberus 2>/dev/null || true

sudo chmod 755 /etc/cerberus
sudo chmod 640 /etc/cerberus/cerberus.ini
sudo chmod 600 /etc/cerberus/environment

# === Initialize User Database ===
echo ""
echo "=== Initializing User Database ==="
if [ -f scripts/init_db.py ]; then
    sudo -u cerberus python3 scripts/init_db.py /etc/cerberus/cerberus.ini
    echo "✓ User database initialized (default user created)"
else
    echo "⚠️ init_db.py not found - you may need to create the first user manually"
fi

echo ""
echo "=== Setup Complete ==="
echo "Next steps:"
echo "1. Edit your secrets:   nano /etc/cerberus/environment"
echo "2. Start the system:    ./bringupall.sh"
echo ""
echo "Default web login user is usually \$000 (check init_db output)"
