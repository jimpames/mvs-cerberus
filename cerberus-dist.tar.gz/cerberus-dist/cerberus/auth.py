"""
cerberus.auth — authentication backend abstraction.

The Web Gate calls AuthBackend.authenticate(username, password) and gets
back a bool. How that bool gets produced is the backend's business.

Default backend (radius): sends a PAP Access-Request to the configured
RADIUS server. Works whether that server is our own embedded pyrad daemon
or an external RADIUS (FreeRADIUS, NPS, cloud, etc).

Fallback backend (direct_sqlite): skips RADIUS entirely and verifies
against Storage directly. Useful when you don't need RADIUS interop
and want one less moving part. Not the default because RADIUS is what
Jim asked for.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Optional

from pyrad.client import Client, Timeout
from pyrad.dictionary import Dictionary
import pyrad.packet

from .storage import Storage
from .radius_dict import RADIUS_DICT_PATH

log = logging.getLogger("cerberus.auth")


# ─── Abstract base ───────────────────────────────────────────────────────────

class AuthBackend(ABC):
    """The interface every concrete auth backend must satisfy."""

    @abstractmethod
    def authenticate(self, username: str, password: str) -> bool: ...


# ─── RADIUS client ───────────────────────────────────────────────────────────

class RadiusClientAuth(AuthBackend):
    """Authenticate by sending a PAP Access-Request to a RADIUS server."""

    def __init__(
        self,
        host: str,
        port: int,
        secret: str,
        timeout: int = 3,
        dictionary_path: Optional[str] = None,
    ):
        if not secret:
            raise ValueError(
                "RADIUS shared secret is empty — set CERBERUS_RADIUS_SECRET in env"
            )
        self.host = host
        self.port = port
        self.timeout = timeout
        dict_path = dictionary_path or RADIUS_DICT_PATH
        self.client = Client(
            server=host,
            authport=port,
            secret=secret.encode("utf-8"),
            dict=Dictionary(dict_path),
        )
        self.client.timeout = timeout
        self.client.retries = 1
        log.info("RADIUS client → %s:%d (timeout=%ds)", host, port, timeout)

    def authenticate(self, username: str, password: str) -> bool:
        try:
            req = self.client.CreateAuthPacket(
                code=pyrad.packet.AccessRequest,
                User_Name=username,
            )
            req["User-Password"] = req.PwCrypt(password)
            req["NAS-Identifier"] = "cerberus-gate"
            reply = self.client.SendPacket(req)
        except Timeout:
            log.error("RADIUS request timed out for user=%r", username)
            return False
        except Exception as e:
            log.exception("RADIUS request failed for user=%r: %s", username, e)
            return False

        if reply.code == pyrad.packet.AccessAccept:
            log.debug("RADIUS accepted user=%r", username)
            return True
        log.info("RADIUS rejected user=%r (code=%d)", username, reply.code)
        return False


# ─── Direct SQLite (bypass RADIUS) ───────────────────────────────────────────

class DirectStorageAuth(AuthBackend):
    """Validate credentials directly against Storage. No RADIUS involved."""

    def __init__(self, storage: Storage):
        self.storage = storage
        log.info("Direct storage auth (bypassing RADIUS)")

    def authenticate(self, username: str, password: str) -> bool:
        return self.storage.verify_password(username, password)


# ─── Factory ─────────────────────────────────────────────────────────────────

def build_auth_backend(cfg: dict, storage: Storage) -> AuthBackend:
    backend = cfg.get("backend", "radius")
    if backend == "radius":
        return RadiusClientAuth(
            host=cfg["radius_host"],
            port=cfg["radius_port"],
            secret=cfg["radius_secret"],
            timeout=cfg.get("radius_timeout", 3),
        )
    if backend == "direct_sqlite":
        return DirectStorageAuth(storage)
    raise ValueError(f"Unsupported auth backend: {backend}")
