"""
cerberus.config — schema-aware INI configuration loader.

The config file is self-describing: every runtime section [X] has a sibling
[__schema__.X] section declaring its keys, types, defaults, and descriptions.

This module:
  • Parses both schemas and values from a single INI file
  • Validates values against schemas at load time
  • Expands ${ENV_VAR} and ${ENV_VAR:default} references
  • Coerces strings to typed values (int, bool, port, etc.)
  • Surfaces schemas to the admin GUI for dynamic form rendering

The algebraic philosophy: Config is a typed record whose schema is data, not
code. Adding a new backend means adding rows to the schema, not editing
parsers.
"""

from __future__ import annotations

import os
import re
import logging
from configparser import ConfigParser, NoSectionError
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

log = logging.getLogger("cerberus.config")

_ENV_REF = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::([^}]*))?\}")


class ConfigError(ValueError):
    """Raised when config is malformed or fails validation."""


# ─── Schema model ────────────────────────────────────────────────────────────

@dataclass
class FieldSchema:
    name: str
    type_spec: str        # e.g. "int(1,1440)", "enum(a,b)", "host"
    default: Optional[str]
    description: str

    @property
    def base_type(self) -> str:
        return self.type_spec.split("(", 1)[0]

    @property
    def is_secret(self) -> bool:
        return self.base_type == "secret"

    @property
    def required(self) -> bool:
        return self.default is None or self.default == ""

    def enum_values(self) -> list[str]:
        if self.base_type != "enum":
            return []
        m = re.match(r"enum\(([^)]*)\)", self.type_spec)
        return [v.strip() for v in m.group(1).split(",")] if m else []

    def int_bounds(self) -> tuple[Optional[int], Optional[int]]:
        m = re.match(r"int\((-?\d+),(-?\d+)\)", self.type_spec)
        if m:
            return int(m.group(1)), int(m.group(2))
        return None, None


@dataclass
class SectionSchema:
    name: str
    title: str
    description: str
    multi_instance: bool
    fields: dict[str, FieldSchema] = field(default_factory=dict)


# ─── Loader ──────────────────────────────────────────────────────────────────

class Config:
    """Schema-aware INI loader. Construct with a path; use .section(name) or
    .sections(prefix) to retrieve typed dicts."""

    SCHEMA_PREFIX = "__schema__."
    META_SECTION = "__meta__"

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._parser = ConfigParser(interpolation=None)
        if not self.path.exists():
            raise ConfigError(f"Config file not found: {self.path}")
        # Preserve case for section names but not keys (ConfigParser default)
        with self.path.open() as f:
            self._parser.read_file(f)
        self._schemas: dict[str, SectionSchema] = self._extract_schemas()
        self._validate_required_sections()
        log.info("Loaded config from %s with %d schemas", self.path, len(self._schemas))

    # ── public api ───────────────────────────────────────────────────────────

    def schemas(self) -> dict[str, SectionSchema]:
        """All section schemas, keyed by section name (without __schema__ prefix)."""
        return self._schemas

    def schema_for(self, section: str) -> Optional[SectionSchema]:
        # For multi-instance sections like [host.tk5], schema is keyed under "host"
        if "." in section:
            return self._schemas.get(section.split(".", 1)[0])
        return self._schemas.get(section)

    def section(self, name: str) -> dict[str, Any]:
        """Get a typed dict for a single-instance section."""
        schema = self._schemas.get(name)
        if not schema:
            raise ConfigError(f"No schema for section [{name}]")
        if schema.multi_instance:
            raise ConfigError(
                f"[{name}] is multi-instance; use config.sections('{name}') instead"
            )
        return self._materialize(name, schema)

    def sections(self, prefix: str) -> dict[str, dict[str, Any]]:
        """Get all instances of a multi-instance section, keyed by instance name.

        E.g. config.sections('host') returns {'tk5': {...}, 'sixpack': {...}}.
        """
        schema = self._schemas.get(prefix)
        if not schema:
            raise ConfigError(f"No schema for section prefix [{prefix}]")
        if not schema.multi_instance:
            raise ConfigError(f"[{prefix}] is not declared multi-instance")
        result: dict[str, dict[str, Any]] = {}
        for sect in self._parser.sections():
            if sect.startswith(f"{prefix}."):
                instance = sect.split(".", 1)[1]
                result[instance] = self._materialize(sect, schema)
        return result

    def meta(self) -> dict[str, str]:
        if not self._parser.has_section(self.META_SECTION):
            return {}
        return dict(self._parser.items(self.META_SECTION))

    # ── internals ────────────────────────────────────────────────────────────

    def _extract_schemas(self) -> dict[str, SectionSchema]:
        schemas: dict[str, SectionSchema] = {}
        for sect in self._parser.sections():
            if not sect.startswith(self.SCHEMA_PREFIX):
                continue
            name = sect.removeprefix(self.SCHEMA_PREFIX)
            schemas[name] = self._parse_schema(sect, name)
        return schemas

    def _parse_schema(self, section: str, name: str) -> SectionSchema:
        raw = dict(self._parser.items(section))
        title = raw.pop("__title__", name)
        description = raw.pop("__description__", "")
        multi_instance = raw.pop("__multi_instance__", "false").lower() in ("true", "yes", "1")

        fields: dict[str, FieldSchema] = {}
        for key, spec in raw.items():
            parts = [p.strip() for p in spec.split("|", 2)]
            type_spec = parts[0] if parts and parts[0] else "str"
            default = parts[1] if len(parts) > 1 and parts[1] != "" else None
            desc = parts[2] if len(parts) > 2 else ""
            fields[key] = FieldSchema(key, type_spec, default, desc)
        return SectionSchema(name, title, description, multi_instance, fields)

    def _validate_required_sections(self) -> None:
        for name, schema in self._schemas.items():
            if schema.multi_instance:
                # Multi-instance sections aren't required to have any instances
                continue
            if not self._parser.has_section(name):
                # Allow if all fields have defaults
                missing = [f.name for f in schema.fields.values() if f.required]
                if missing:
                    raise ConfigError(
                        f"Section [{name}] is missing and these fields have no defaults: {missing}"
                    )

    def _materialize(self, section: str, schema: SectionSchema) -> dict[str, Any]:
        try:
            raw_items = dict(self._parser.items(section))
        except NoSectionError:
            raw_items = {}

        result: dict[str, Any] = {}
        for fname, fspec in schema.fields.items():
            if fname in raw_items:
                raw_value = raw_items[fname]
            elif fspec.default is not None:
                raw_value = fspec.default
            else:
                raise ConfigError(f"[{section}].{fname} is required (no default)")

            expanded = self._expand_env(raw_value)
            if expanded == "" and not fspec.required:
                expanded = fspec.default or ""

            result[fname] = self._coerce(expanded, fspec, f"[{section}].{fname}")
        return result

    @staticmethod
    def _expand_env(value: str) -> str:
        """Expand ${VAR} and ${VAR:default} references."""
        def repl(m: re.Match) -> str:
            var, default = m.group(1), m.group(2)
            return os.environ.get(var, default if default is not None else "")
        return _ENV_REF.sub(repl, value)

    @staticmethod
    def _coerce(value: str, spec: FieldSchema, where: str) -> Any:
        bt = spec.base_type
        if bt == "str" or bt == "secret" or bt == "path":
            return value
        if bt == "host":
            if not value:
                raise ConfigError(f"{where}: host required")
            return value
        if bt == "port":
            try:
                p = int(value)
            except ValueError as e:
                raise ConfigError(f"{where}: port must be integer, got {value!r}") from e
            if not 1 <= p <= 65535:
                raise ConfigError(f"{where}: port {p} out of range")
            return p
        if bt == "int":
            try:
                n = int(value)
            except ValueError as e:
                raise ConfigError(f"{where}: int expected, got {value!r}") from e
            lo, hi = spec.int_bounds()
            if lo is not None and n < lo:
                raise ConfigError(f"{where}: {n} below minimum {lo}")
            if hi is not None and n > hi:
                raise ConfigError(f"{where}: {n} above maximum {hi}")
            return n
        if bt == "bool":
            v = value.strip().lower()
            if v in ("true", "yes", "on", "1"):
                return True
            if v in ("false", "no", "off", "0", ""):
                return False
            raise ConfigError(f"{where}: bool expected, got {value!r}")
        if bt == "enum":
            allowed = spec.enum_values()
            if value not in allowed:
                raise ConfigError(f"{where}: {value!r} not in {allowed}")
            return value
        # Unknown type — pass through as string with a warning
        log.warning("Unknown type %r for %s; treating as str", spec.type_spec, where)
        return value


# ─── Convenience ─────────────────────────────────────────────────────────────

def load(path: str | Path) -> Config:
    return Config(path)
