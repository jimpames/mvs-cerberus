"""
cerberus.admin — schema-driven admin GUI.

The admin endpoints read the Config's schemas at request time and render
the appropriate form widgets for each section. Adding a new field to the
INI schema makes it appear in the admin GUI automatically — no template
changes needed.

This is the self-bootstrapping part: the config describes itself, and
the GUI is a rendering of the config description.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from flask import (
    Blueprint, abort, current_app, jsonify, render_template, request, url_for
)

from .config import Config, FieldSchema, SectionSchema

log = logging.getLogger("cerberus.admin")

admin_bp = Blueprint("admin", __name__, template_folder="../templates")


def _bind_local_only() -> None:
    """Restrict admin routes to localhost connections when configured."""
    cfg: Config = current_app.config["cerberus_cfg"]
    gate_cfg = cfg.section("gate")
    if not gate_cfg.get("admin_bind_local", True):
        return
    remote = request.remote_addr or ""
    if not (remote.startswith("127.") or remote == "::1" or remote == "localhost"):
        log.warning("Admin access denied from %s", remote)
        abort(403)


@admin_bp.before_request
def _gate():
    _bind_local_only()


# ─── Dashboard ───────────────────────────────────────────────────────────────

@admin_bp.route("/", methods=["GET"])
def dashboard():
    cfg: Config = current_app.config["cerberus_cfg"]
    storage = current_app.config["cerberus_storage"]
    gate = current_app.config["cerberus_gate"]

    schemas = cfg.schemas()
    sections = []
    for name, schema in schemas.items():
        if schema.multi_instance:
            instances = cfg.sections(name)
            sections.append({
                "name": name,
                "title": schema.title,
                "description": schema.description,
                "multi": True,
                "instances": instances,
            })
        else:
            sections.append({
                "name": name,
                "title": schema.title,
                "description": schema.description,
                "multi": False,
                "values": cfg.section(name) if cfg._parser.has_section(name)
                          else {f.name: f.default for f in schema.fields.values()},
            })
    return render_template(
        "admin.html",
        meta=cfg.meta(),
        sections=sections,
        users=storage.list_users(),
        recent_events=storage.list_events(50),
        gate_status=gate.status(),
    )


# ─── Users ───────────────────────────────────────────────────────────────────

@admin_bp.route("/users", methods=["GET"])
def list_users():
    storage = current_app.config["cerberus_storage"]
    return jsonify([
        {
            "username": u.username,
            "enabled": u.enabled,
            "created_at": u.created_at,
            "last_logon": u.last_logon,
            "last_logon_ip": u.last_logon_ip,
        }
        for u in storage.list_users()
    ])


@admin_bp.route("/users", methods=["POST"])
def add_user():
    storage = current_app.config["cerberus_storage"]
    data = request.get_json() or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    if not username or not password:
        return jsonify({"ok": False, "error": "username and password required"}), 400
    try:
        storage.add_user(username, password, enabled=True)
        storage.log_event("admin.add_user", username, request.remote_addr)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    return jsonify({"ok": True})


@admin_bp.route("/users/<username>/password", methods=["POST"])
def change_password(username: str):
    storage = current_app.config["cerberus_storage"]
    data = request.get_json() or {}
    new_password = data.get("password") or ""
    if not new_password:
        return jsonify({"ok": False, "error": "password required"}), 400
    try:
        storage.set_password(username, new_password)
        storage.log_event("admin.change_password", username, request.remote_addr)
    except KeyError:
        return jsonify({"ok": False, "error": "user not found"}), 404
    return jsonify({"ok": True})


@admin_bp.route("/users/<username>", methods=["DELETE"])
def delete_user(username: str):
    storage = current_app.config["cerberus_storage"]
    storage.delete_user(username)
    storage.log_event("admin.delete_user", username, request.remote_addr)
    return jsonify({"ok": True})


@admin_bp.route("/users/<username>/enabled", methods=["POST"])
def toggle_user(username: str):
    storage = current_app.config["cerberus_storage"]
    data = request.get_json() or {}
    enabled = bool(data.get("enabled", True))
    try:
        storage.set_enabled(username, enabled)
        storage.log_event(
            "admin.toggle_user", username, request.remote_addr,
            f"enabled={enabled}",
        )
    except KeyError:
        return jsonify({"ok": False, "error": "user not found"}), 404
    return jsonify({"ok": True})


# ─── Schema introspection (for the front-end form renderer) ─────────────────

@admin_bp.route("/schema", methods=["GET"])
def schema():
    """Expose the parsed schema as JSON so the front-end can render form
    fields for new section types without re-templating."""
    cfg: Config = current_app.config["cerberus_cfg"]
    out = {}
    for name, sch in cfg.schemas().items():
        out[name] = {
            "title": sch.title,
            "description": sch.description,
            "multi_instance": sch.multi_instance,
            "fields": {
                fname: {
                    "type": f.type_spec,
                    "base_type": f.base_type,
                    "default": f.default,
                    "description": f.description,
                    "is_secret": f.is_secret,
                    "required": f.required,
                    "enum_values": f.enum_values(),
                }
                for fname, f in sch.fields.items()
            },
        }
    return jsonify(out)
