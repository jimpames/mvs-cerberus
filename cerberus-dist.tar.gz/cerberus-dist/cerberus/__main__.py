"""
cerberus.__main__ — composes the algebraic core from config and starts the gate.

This is the only file that knows how all the components fit together.
Each component is built from its config section and handed to its
dependents through the constructor.

  Storage          ← storage.dsn
  RadiusServer     ← Storage (for user lookup) + radius_server.*
  AuthBackend      ← Storage + auth.*
  Turret           ← turret.* + [host.*]
  GateManager      ← AuthBackend + Storage + Turret + gate.session_minutes
  Flask app        ← Config + GateManager + Storage

Usage:
  python -m cerberus /etc/cerberus/cerberus.ini
  python -m cerberus  # reads CERBERUS_CONFIG env or ./config/cerberus.ini
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

from waitress import serve

from .auth import build_auth_backend
from .config import Config, ConfigError, load as load_config
from .exposure import build_exposure
from .gate import GateManager
from .radius_server import EmbeddedRadiusServer
from .storage import build_storage
from .turret import build_turret
from .web import create_app


def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )


def resolve_config_path(arg: str | None) -> Path:
    candidates = [
        arg,
        os.environ.get("CERBERUS_CONFIG"),
        "/etc/cerberus/cerberus.ini",
        "./config/cerberus.ini",
    ]
    for c in candidates:
        if c and Path(c).exists():
            return Path(c)
    raise SystemExit(
        "No config file found. Tried: " +
        ", ".join(str(c) for c in candidates if c) +
        "\nCreate one from config/cerberus.ini.example."
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="cerberus", description="Cerberus Gate")
    parser.add_argument("config", nargs="?", help="Path to cerberus.ini")
    parser.add_argument("--log-level", default="INFO")
    parser.add_argument("--dev", action="store_true",
                        help="Use Flask dev server instead of waitress")
    args = parser.parse_args(argv)

    setup_logging(args.log_level)
    log = logging.getLogger("cerberus")

    cfg_path = resolve_config_path(args.config)
    log.info("Loading config from %s", cfg_path)
    try:
        cfg = load_config(cfg_path)
    except ConfigError as e:
        log.error("Config error: %s", e)
        return 2

    # ── compose components ──────────────────────────────────────────────────
    storage = build_storage(cfg.section("storage"))

    radius_srv = None
    rs_cfg = cfg.section("radius_server")
    if rs_cfg.get("enabled", True):
        radius_srv = EmbeddedRadiusServer(
            storage=storage,
            listen_addr=rs_cfg["listen_addr"],
            listen_port=rs_cfg["listen_port"],
            secret=rs_cfg["secret"],
            dictionary_path=rs_cfg.get("dictionary_path") or None,
        )
        radius_srv.start()

    auth = build_auth_backend(cfg.section("auth"), storage)
    turret = build_turret(cfg.section("turret"), cfg.sections("host"))
    exposure = build_exposure(cfg.section("exposure"))

    gate_cfg = cfg.section("gate")
    gate = GateManager(
        auth=auth,
        storage=storage,
        turret=turret,
        exposure=exposure,
        session_minutes=gate_cfg["session_minutes"],
    )

    # ── start the web app ───────────────────────────────────────────────────
    app = create_app(cfg, gate, storage)
    listen_addr = gate_cfg["listen_addr"]
    listen_port = gate_cfg["listen_port"]
    log.info("Starting Cerberus Gate on %s:%d", listen_addr, listen_port)

    try:
        if args.dev:
            app.run(host=listen_addr, port=listen_port, debug=True, use_reloader=False)
        else:
            serve(app, host=listen_addr, port=listen_port, threads=8)
    except KeyboardInterrupt:
        log.info("Shutdown requested")
    finally:
        gate.shutdown()
        if radius_srv:
            radius_srv.stop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
