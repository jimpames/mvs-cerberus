"""Cerberus Gate — algebraic MVS access perimeter."""

__version__ = "2.0.0"
