"""
cerberus.gate — session manager.

The Gate sits between the Web Gate's HTTP endpoints and the rest of the
algebraic core. It tracks granted sessions, enforces leases, and ensures
the Turret stays running while there are active sessions.

The Turret is reference-counted: it starts when the first session is
granted and stops when the last expires or is revoked. This is the
"defense in depth" gate — the TN3270 listener literally does not exist
when no user has been authorized within the lease window.
"""

from __future__ import annotations

import logging
import secrets
import threading
import time
from contextlib import suppress
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from .auth import AuthBackend
from .exposure import Exposure
from .storage import Storage
from .turret import Turret

log = logging.getLogger("cerberus.gate")


# ─── Session record ──────────────────────────────────────────────────────────

@dataclass
class Session:
    sid: str
    username: str
    granted_at: datetime
    expires_at: datetime
    client_ip: str

    def remaining_seconds(self) -> int:
        return max(0, int((self.expires_at - datetime.now(timezone.utc)).total_seconds()))

    def expired(self) -> bool:
        return self.remaining_seconds() == 0


# ─── Gate Manager ────────────────────────────────────────────────────────────

class GateManager:
    """Owns the session table and the Turret lifecycle."""

    def __init__(
        self,
        auth: AuthBackend,
        storage: Storage,
        turret: Turret,
        exposure: Exposure,
        session_minutes: int,
    ):
        self.auth = auth
        self.storage = storage
        self.turret = turret
        self.exposure = exposure
        self.session_minutes = session_minutes

        self._lock = threading.RLock()
        self._sessions: dict[str, Session] = {}
        self._reaper = threading.Thread(target=self._reaper_loop, daemon=True, name="cerberus-reaper")
        self._reaper.start()

    # ── public API ───────────────────────────────────────────────────────────

    def grant(self, username: str, password: str, client_ip: str) -> Optional[Session]:
        """Authenticate; on success register a session and ensure Turret is up."""
        if not self.auth.authenticate(username, password):
            self.storage.log_event("gate.reject", username, client_ip)
            return None

        with self._lock:
            sid = secrets.token_urlsafe(16)
            now = datetime.now(timezone.utc)
            sess = Session(
                sid=sid,
                username=username,
                granted_at=now,
                expires_at=now + timedelta(minutes=self.session_minutes),
                client_ip=client_ip,
            )
            self._sessions[sid] = sess
            self.storage.record_logon(username, client_ip)
            self.storage.log_event("gate.grant", username, client_ip, f"sid={sid[:8]}")
            try:
                self.turret.start()
                self.exposure.start()
            except Exception as e:
                log.exception("Surface start failed during grant: %s", e)
                # Roll back the session — no point granting if we can't serve
                del self._sessions[sid]
                # Best-effort teardown of whatever did come up
                with suppress(Exception):
                    self.exposure.stop()
                with suppress(Exception):
                    self.turret.stop()
                self.storage.log_event("gate.surface_fail", username, client_ip, str(e))
                return None
            public_url = self.exposure.public_url()
            log.info(
                "GRANT user=%s ip=%s sid=%s expires=%s public=%s",
                username, client_ip, sid[:8], sess.expires_at.isoformat(),
                public_url or "(no tunnel)",
            )
            return sess

    def revoke(self, sid: str) -> bool:
        with self._lock:
            sess = self._sessions.pop(sid, None)
            if not sess:
                return False
            log.info("REVOKE sid=%s user=%s", sid[:8], sess.username)
            self.storage.log_event("gate.revoke", sess.username, sess.client_ip, f"sid={sid[:8]}")
            self._maybe_stop_turret()
            return True

    def extend(self, sid: str) -> Optional[Session]:
        with self._lock:
            sess = self._sessions.get(sid)
            if not sess or sess.expired():
                return None
            sess.expires_at = datetime.now(timezone.utc) + timedelta(minutes=self.session_minutes)
            self.storage.log_event("gate.extend", sess.username, sess.client_ip, f"sid={sid[:8]}")
            log.info("EXTEND sid=%s new_expiry=%s", sid[:8], sess.expires_at.isoformat())
            return sess

    def get_session(self, sid: str) -> Optional[Session]:
        with self._lock:
            return self._sessions.get(sid)

    def status(self) -> dict:
        with self._lock:
            active = [s for s in self._sessions.values() if not s.expired()]
            return {
                "active_sessions": len(active),
                "turret_running": self.turret.is_running(),
                "exposure_running": self.exposure.is_running(),
                "public_url": self.exposure.public_url(),
                "sessions": [
                    {
                        "user": s.username,
                        "ip": s.client_ip,
                        "remaining_sec": s.remaining_seconds(),
                    }
                    for s in active
                ],
            }

    def shutdown(self) -> None:
        with self._lock:
            for sid in list(self._sessions):
                self._sessions.pop(sid, None)
            self.turret.stop()
            self.exposure.stop()

    # ── internals ────────────────────────────────────────────────────────────

    def _maybe_stop_turret(self) -> None:
        if any(not s.expired() for s in self._sessions.values()):
            return
        log.info("No active sessions — stopping turret and exposure")
        try:
            self.turret.stop()
        except Exception as e:
            log.warning("Turret stop failed: %s", e)
        try:
            self.exposure.stop()
        except Exception as e:
            log.warning("Exposure stop failed: %s", e)

    def _reaper_loop(self) -> None:
        while True:
            time.sleep(10)
            try:
                with self._lock:
                    expired = [sid for sid, s in self._sessions.items() if s.expired()]
                    for sid in expired:
                        sess = self._sessions[sid]
                        log.info("EXPIRE sid=%s user=%s", sid[:8], sess.username)
                        self.storage.log_event(
                            "gate.expire", sess.username, sess.client_ip, f"sid={sid[:8]}"
                        )
                        del self._sessions[sid]
                    if expired:
                        self._maybe_stop_turret()
            except Exception as e:
                log.exception("Reaper iteration failed: %s", e)
