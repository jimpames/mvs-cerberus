"""
cerberus.radius_server — embedded RADIUS server (pyrad).

Listens on UDP for Access-Request packets, looks up users in Storage,
and replies with Access-Accept or Access-Reject. PAP only — that's what
Cerberus's Web Gate sends.

This runs in a background thread so the Flask front-end and the RADIUS
daemon share one Python process, sharing the same Storage instance.
Operators who prefer FreeRADIUS / NPS / cloud RADIUS set
radius_server.enabled=false and point auth.radius_host elsewhere.
"""

from __future__ import annotations

import logging
import threading
from typing import Optional

from pyrad.dictionary import Dictionary
from pyrad.server import RemoteHost, Server
import pyrad.packet

from .radius_dict import RADIUS_DICT_PATH
from .storage import Storage

log = logging.getLogger("cerberus.radius_server")


class _CerberusServer(Server):
    """pyrad Server subclass that delegates user lookup to Storage."""

    def __init__(self, storage: Storage, **kwargs):
        super().__init__(**kwargs)
        self.storage = storage

    def HandleAuthPacket(self, pkt) -> None:
        username = pkt.get(1, [None])[0] if 1 in pkt else None
        if isinstance(username, bytes):
            username = username.decode("utf-8", errors="replace")
        # User-Password is encrypted with the shared secret; pyrad decrypts.
        try:
            pwd_bytes = pkt["User-Password"][0]
            if isinstance(pwd_bytes, str):
                pwd_bytes = pwd_bytes.encode("latin-1", errors="surrogateescape")
            password = pkt.PwDecrypt(pwd_bytes)
            if isinstance(password, bytes):
                password = password.decode("utf-8", errors="replace").rstrip("\x00")
            elif isinstance(password, str):
                password = password.rstrip("\x00")
        except Exception as e:
            log.warning("Failed to decrypt password in RADIUS packet: %s", e)
            reply = self.CreateReplyPacket(pkt, **{"Reply-Message": "Malformed request"})
            reply.code = pyrad.packet.AccessReject
            self.SendReplyPacket(pkt.fd, reply)
            return

        client_id = pkt.source[0] if hasattr(pkt, "source") else "unknown"
        accepted = bool(username) and self.storage.verify_password(username, password)

        reply = self.CreateReplyPacket(pkt)
        if accepted:
            reply.code = pyrad.packet.AccessAccept
            reply["Reply-Message"] = "Access granted"
            self.storage.log_event(
                event_type="radius.accept",
                username=username,
                client_ip=client_id,
            )
            log.info("RADIUS accept user=%r from %s", username, client_id)
        else:
            reply.code = pyrad.packet.AccessReject
            reply["Reply-Message"] = "Access denied"
            self.storage.log_event(
                event_type="radius.reject",
                username=username,
                client_ip=client_id,
            )
            log.info("RADIUS reject user=%r from %s", username, client_id)
        self.SendReplyPacket(pkt.fd, reply)


class EmbeddedRadiusServer:
    """Lifecycle wrapper — owns the pyrad Server thread."""

    def __init__(
        self,
        storage: Storage,
        listen_addr: str,
        listen_port: int,
        secret: str,
        dictionary_path: Optional[str] = None,
    ):
        if not secret:
            raise ValueError(
                "Embedded RADIUS server requires a shared secret "
                "(set CERBERUS_RADIUS_SECRET in env)"
            )
        self.listen_addr = listen_addr
        self.listen_port = listen_port
        self._server: Optional[_CerberusServer] = None
        self._thread: Optional[threading.Thread] = None
        self._dict_path = dictionary_path or RADIUS_DICT_PATH

        # The RemoteHost identifies who's allowed to send us requests; for
        # the embedded case the Web Gate is on the same loopback, but we
        # accept from anywhere on the listen_addr to support sidecar
        # deployments where the gate is a separate container/host.
        self._secret = secret.encode("utf-8")
        self._storage = storage

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            log.debug("Embedded RADIUS already running")
            return

        # pyrad expects a hosts dict mapping client IP → (secret, name)
        hosts = {
            "0.0.0.0": RemoteHost("0.0.0.0", self._secret, "cerberus-gate"),
            "127.0.0.1": RemoteHost("127.0.0.1", self._secret, "cerberus-gate"),
        }
        self._server = _CerberusServer(
            storage=self._storage,
            addresses=[self.listen_addr],
            authport=self.listen_port,
            hosts=hosts,
            dict=Dictionary(self._dict_path),
        )

        def run():
            log.info(
                "Embedded RADIUS server listening on %s:%d",
                self.listen_addr, self.listen_port,
            )
            try:
                self._server.Run()
            except Exception as e:
                log.exception("RADIUS server crashed: %s", e)

        self._thread = threading.Thread(target=run, daemon=True, name="cerberus-radius")
        self._thread.start()

    def stop(self) -> None:
        # pyrad's Server has no clean stop — relies on daemon thread exiting
        # when the main process does. That's acceptable for our lifecycle.
        if self._server:
            try:
                self._server.BindToAddress = lambda *a, **k: None  # no-op
            except Exception:
                pass
        log.info("RADIUS server stop requested (will exit with main process)")
