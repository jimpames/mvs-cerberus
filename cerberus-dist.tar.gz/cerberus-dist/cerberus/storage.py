"""
cerberus.storage — persistence layer.

Algebraic factoring:
  Storage is an abstract interface. SqliteStorage is the default concrete
  implementation. Swapping to PostgreSQL, MySQL, or anything else means
  writing a new subclass and changing one config key.

The RADIUS server and the Web Gate both read users through this interface
without knowing or caring about the underlying engine.
"""

from __future__ import annotations

import logging
import os
import sqlite3
import threading
from abc import ABC, abstractmethod
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Optional

import bcrypt

log = logging.getLogger("cerberus.storage")


# ─── Domain types ────────────────────────────────────────────────────────────

@dataclass
class User:
    username: str
    enabled: bool
    created_at: str
    last_logon: Optional[str]
    last_logon_ip: Optional[str]


@dataclass
class AuditEvent:
    id: int
    timestamp: str
    event_type: str
    username: Optional[str]
    client_ip: Optional[str]
    details: Optional[str]


# ─── Abstract Storage ────────────────────────────────────────────────────────

class Storage(ABC):
    """The interface every concrete storage backend must satisfy."""

    # Users
    @abstractmethod
    def add_user(self, username: str, password: str, enabled: bool = True) -> None: ...
    @abstractmethod
    def get_user(self, username: str) -> Optional[User]: ...
    @abstractmethod
    def list_users(self) -> list[User]: ...
    @abstractmethod
    def set_password(self, username: str, new_password: str) -> None: ...
    @abstractmethod
    def set_enabled(self, username: str, enabled: bool) -> None: ...
    @abstractmethod
    def delete_user(self, username: str) -> None: ...

    # Auth
    @abstractmethod
    def verify_password(self, username: str, password: str) -> bool: ...
    @abstractmethod
    def record_logon(self, username: str, client_ip: str) -> None: ...

    # Audit
    @abstractmethod
    def log_event(
        self,
        event_type: str,
        username: Optional[str] = None,
        client_ip: Optional[str] = None,
        details: Optional[str] = None,
    ) -> None: ...
    @abstractmethod
    def list_events(self, limit: int = 100) -> list[AuditEvent]: ...


# ─── SQLite implementation ───────────────────────────────────────────────────

class SqliteStorage(Storage):
    """SQLite-backed storage. Thread-safe via per-call connections."""

    SCHEMA_SQL = """
        CREATE TABLE IF NOT EXISTS users (
            username       TEXT PRIMARY KEY,
            password_hash  TEXT NOT NULL,
            enabled        INTEGER NOT NULL DEFAULT 1,
            created_at     TEXT NOT NULL DEFAULT (datetime('now')),
            last_logon     TEXT,
            last_logon_ip  TEXT
        );
        CREATE TABLE IF NOT EXISTS audit_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp   TEXT NOT NULL DEFAULT (datetime('now')),
            event_type  TEXT NOT NULL,
            username    TEXT,
            client_ip   TEXT,
            details     TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(timestamp DESC);
        CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(username);
    """

    def __init__(self, dsn: str):
        self.dsn = dsn
        self._lock = threading.RLock()
        Path(dsn).parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()
        log.info("SQLite storage opened: %s", dsn)

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.dsn, timeout=10.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self._lock, self._conn() as c:
            c.executescript(self.SCHEMA_SQL)

    # ── users ────────────────────────────────────────────────────────────────

    def add_user(self, username: str, password: str, enabled: bool = True) -> None:
        h = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
        with self._lock, self._conn() as c:
            c.execute(
                "INSERT INTO users(username, password_hash, enabled) VALUES (?,?,?)",
                (username, h, 1 if enabled else 0),
            )
        log.info("Added user %s (enabled=%s)", username, enabled)

    def get_user(self, username: str) -> Optional[User]:
        with self._lock, self._conn() as c:
            row = c.execute(
                "SELECT username, enabled, created_at, last_logon, last_logon_ip "
                "FROM users WHERE username = ?",
                (username,),
            ).fetchone()
        if not row:
            return None
        return User(
            username=row["username"],
            enabled=bool(row["enabled"]),
            created_at=row["created_at"],
            last_logon=row["last_logon"],
            last_logon_ip=row["last_logon_ip"],
        )

    def list_users(self) -> list[User]:
        with self._lock, self._conn() as c:
            rows = c.execute(
                "SELECT username, enabled, created_at, last_logon, last_logon_ip "
                "FROM users ORDER BY username"
            ).fetchall()
        return [
            User(
                username=r["username"],
                enabled=bool(r["enabled"]),
                created_at=r["created_at"],
                last_logon=r["last_logon"],
                last_logon_ip=r["last_logon_ip"],
            )
            for r in rows
        ]

    def set_password(self, username: str, new_password: str) -> None:
        h = bcrypt.hashpw(new_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
        with self._lock, self._conn() as c:
            cur = c.execute(
                "UPDATE users SET password_hash = ? WHERE username = ?",
                (h, username),
            )
            if cur.rowcount == 0:
                raise KeyError(username)
        log.info("Password updated for %s", username)

    def set_enabled(self, username: str, enabled: bool) -> None:
        with self._lock, self._conn() as c:
            cur = c.execute(
                "UPDATE users SET enabled = ? WHERE username = ?",
                (1 if enabled else 0, username),
            )
            if cur.rowcount == 0:
                raise KeyError(username)

    def delete_user(self, username: str) -> None:
        with self._lock, self._conn() as c:
            c.execute("DELETE FROM users WHERE username = ?", (username,))

    # ── auth ─────────────────────────────────────────────────────────────────

    def verify_password(self, username: str, password: str) -> bool:
        with self._lock, self._conn() as c:
            row = c.execute(
                "SELECT password_hash, enabled FROM users WHERE username = ?",
                (username,),
            ).fetchone()
        if not row:
            # Run a dummy bcrypt to keep timing constant against username enumeration
            try:
                bcrypt.checkpw(b"x", b"$2b$12$abcdefghijklmnopqrstuv")
            except Exception:
                pass
            return False
        if not row["enabled"]:
            return False
        try:
            return bcrypt.checkpw(password.encode("utf-8"), row["password_hash"].encode("utf-8"))
        except Exception as e:
            log.exception("bcrypt failed for %s: %s", username, e)
            return False

    def record_logon(self, username: str, client_ip: str) -> None:
        with self._lock, self._conn() as c:
            c.execute(
                "UPDATE users SET last_logon = datetime('now'), last_logon_ip = ? "
                "WHERE username = ?",
                (client_ip, username),
            )

    # ── audit ────────────────────────────────────────────────────────────────

    def log_event(
        self,
        event_type: str,
        username: Optional[str] = None,
        client_ip: Optional[str] = None,
        details: Optional[str] = None,
    ) -> None:
        with self._lock, self._conn() as c:
            c.execute(
                "INSERT INTO audit_log(event_type, username, client_ip, details) "
                "VALUES (?,?,?,?)",
                (event_type, username, client_ip, details),
            )

    def list_events(self, limit: int = 100) -> list[AuditEvent]:
        with self._lock, self._conn() as c:
            rows = c.execute(
                "SELECT id, timestamp, event_type, username, client_ip, details "
                "FROM audit_log ORDER BY id DESC LIMIT ?",
                (int(limit),),
            ).fetchall()
        return [
            AuditEvent(
                id=r["id"],
                timestamp=r["timestamp"],
                event_type=r["event_type"],
                username=r["username"],
                client_ip=r["client_ip"],
                details=r["details"],
            )
            for r in rows
        ]


# ─── Factory ─────────────────────────────────────────────────────────────────

def build_storage(cfg: dict) -> Storage:
    """Construct a Storage instance from the [storage] config section."""
    backend = cfg.get("backend", "sqlite")
    if backend == "sqlite":
        return SqliteStorage(cfg["dsn"])
    raise ValueError(f"Unsupported storage backend: {backend}")
