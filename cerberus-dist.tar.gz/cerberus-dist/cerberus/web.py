"""
cerberus.web — Flask front-end.

Two route groups:
  • Auth flow: /, /auth, /granted, /extend, /logout, /status
  • Admin: /admin (mounted from cerberus.admin if enabled in config)

The Flask app holds references to the algebraic components (GateManager,
Storage, Config) but never instantiates them itself — that's the job of
cerberus.__main__.
"""

from __future__ import annotations

import logging
import secrets
from typing import Optional

from flask import (
    Flask, abort, jsonify, redirect, render_template, request, session, url_for
)

from .config import Config
from .gate import GateManager
from .storage import Storage

log = logging.getLogger("cerberus.web")


def create_app(
    cfg: Config,
    gate: GateManager,
    storage: Storage,
) -> Flask:
    gate_cfg = cfg.section("gate")
    hosts = cfg.sections("host")

    app = Flask(__name__,
                    static_folder='/opt/cerberus/static',
                    static_url_path='/static',
                    template_folder='/opt/cerberus/templates')
    app.config["cerberus_cfg"] = cfg
    app.config["cerberus_gate"] = gate
    app.config["cerberus_storage"] = storage
    app.secret_key = gate_cfg.get("secret_key") or secrets.token_hex(32)

    # ── helpers ──────────────────────────────────────────────────────────────

    def client_ip() -> str:
        fwd = request.headers.get("X-Forwarded-For", "")
        if fwd:
            return fwd.split(",")[0].strip()
        return request.remote_addr or "unknown"

    # ── auth routes ──────────────────────────────────────────────────────────

    @app.route("/", methods=["GET"])
    def root():
        return redirect(url_for("auth"))

    @app.route("/auth", methods=["GET", "POST"])
    def auth():
        error: Optional[str] = None
        if request.method == "POST":
            username = (request.form.get("logon_id") or "").strip()
            password = request.form.get("password") or ""
            if not username or not password:
                error = "LOGON ID AND PASSWORD REQUIRED"
            else:
                sess = gate.grant(username=username, password=password, client_ip=client_ip())
                if sess:
                    session["sid"] = sess.sid
                    session["user"] = sess.username
                    return redirect(url_for("granted"))
                error = "ACCESS DENIED — INVALID CREDENTIALS"
        return render_template("cerberus.html", error=error)

    @app.route("/granted", methods=["GET"])
    def granted():
        sid = session.get("sid")
        if not sid:
            return redirect(url_for("auth"))
        sess = gate.get_session(sid)
        if not sess or sess.expired():
            session.pop("sid", None)
            session.pop("user", None)
            return redirect(url_for("auth"))
        return render_template(
            "granted.html",
            user=sess.username,
            hostname=gate_cfg["public_hostname"],
            port=cfg.section("turret")["listen_port"],
            public_url=gate.exposure.public_url(),
            remaining=sess.remaining_seconds(),
            hosts=hosts,
        )

    @app.route("/extend", methods=["POST"])
    def extend():
        sid = session.get("sid")
        if not sid:
            return jsonify({"ok": False, "reason": "no_session"}), 401
        sess = gate.extend(sid)
        if not sess:
            return jsonify({"ok": False, "reason": "expired"}), 410
        return jsonify({"ok": True, "remaining_sec": sess.remaining_seconds()})

    @app.route("/logout", methods=["POST"])
    def logout():
        sid = session.pop("sid", None)
        session.pop("user", None)
        if sid:
            gate.revoke(sid)
        return redirect(url_for("auth"))

    @app.route("/status")
    def status():
        # Lock down to loopback to avoid leaking session info to the public
        if not client_ip().startswith("127.") and client_ip() != "::1":
            abort(403)
        return jsonify(gate.status())

    # ── admin (optional) ─────────────────────────────────────────────────────

    if gate_cfg.get("admin_enabled", True):
        from .admin import admin_bp
        app.register_blueprint(admin_bp, url_prefix="/admin")
        log.info("Admin GUI mounted at /admin")

    return app
