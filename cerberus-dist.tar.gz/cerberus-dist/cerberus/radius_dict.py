"""
cerberus.radius_dict — bundled RADIUS dictionary file.

We ship a minimal RFC 2865 dictionary inline rather than depending on the
distro's /usr/share/freeradius/dictionary tree. Keeps Cerberus self-contained
and portable to s390x zLinux where FreeRADIUS may not be installed.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

# Minimal RADIUS dictionary covering attributes Cerberus actually uses.
# Format follows the FreeRADIUS dictionary syntax that pyrad understands.
RADIUS_DICT_TEXT = """\
#
# Cerberus minimal RADIUS dictionary
# Subset of RFC 2865 / 2866 attributes used by the gate.
#
ATTRIBUTE	User-Name		1	string
ATTRIBUTE	User-Password		2	octets
ATTRIBUTE	CHAP-Password		3	octets
ATTRIBUTE	NAS-IP-Address		4	ipaddr
ATTRIBUTE	NAS-Port		5	integer
ATTRIBUTE	Service-Type		6	integer
ATTRIBUTE	Framed-Protocol		7	integer
ATTRIBUTE	Reply-Message		18	string
ATTRIBUTE	State			24	string
ATTRIBUTE	Class			25	string
ATTRIBUTE	Vendor-Specific		26	string
ATTRIBUTE	Session-Timeout		27	integer
ATTRIBUTE	Idle-Timeout		28	integer
ATTRIBUTE	Called-Station-Id	30	string
ATTRIBUTE	Calling-Station-Id	31	string
ATTRIBUTE	NAS-Identifier		32	string
ATTRIBUTE	Proxy-State		33	string
ATTRIBUTE	Acct-Status-Type	40	integer
ATTRIBUTE	Acct-Session-Id		44	string
ATTRIBUTE	NAS-Port-Type		61	integer
ATTRIBUTE	Message-Authenticator	80	octets

#
# Service-Type values
#
VALUE	Service-Type	Login-User		1
VALUE	Service-Type	Framed-User		2
VALUE	Service-Type	Authenticate-Only	8
"""


def _write_bundled_dict() -> str:
    """Write the bundled dict to a temp file and return its path."""
    fd, path = tempfile.mkstemp(prefix="cerberus_radius_", suffix=".dict")
    with os.fdopen(fd, "w") as f:
        f.write(RADIUS_DICT_TEXT)
    return path


# Materialize the dictionary file once at import time.
RADIUS_DICT_PATH = _write_bundled_dict()
