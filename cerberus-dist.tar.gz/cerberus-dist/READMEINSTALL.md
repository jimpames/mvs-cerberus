# Cerberus Gate v2 - Installation Guide

## Quick Install (Recommended)

```bash
# 1. Extract the package
tar -xzf cerberus-dist.tar.gz
cd cerberus-dist/cerberus
sudo ./setup.sh
./bringupall.sh



Detailed Steps
1. Extract
Bashtar -xzf cerberus-dist.tar.gz
cd cerberus-dist/cerberus
2. Run Setup (Important)
Bashsudo ./setup.sh
This does:

Creates /etc/cerberus/ and log directories
Copies config templates
Initializes the SQLite user database (creates first user)
Sets correct permissions

3. Edit Secrets
Bashnano /etc/cerberus/environment
Replace the placeholder values with your real ones.
4. Start the System
Bash./bringupall.sh

First User Login
After running setup.sh, a default user is usually created.
Check the output of setup.sh for the username and password (commonly $000 / music or similar).
You can then log in at: https://auth.tso3270.com

For full technical documentation, see README.md
Made for the mainframe hobbyist community.
EOF




3. Configure Your Secrets
Bash nano /etc/cerberus/environment
Edit the following values - running init_db.py creates first radius user:

NGROK_AUTHTOKEN=your_real_token_here
CERBERUS_RADIUS_SECRET=your_strong_secret
CERBERUS_SECRET_KEY=your_strong_key


4. Start Cerberus
Bash./bringupall.sh
5. Test Access

Web: https://auth.tso3270.com
TN3270: tso.tso3270.com:26640


Troubleshooting

Banner not showing? → Run ./setup.sh again
Permission errors? → Run sudo ./setup.sh
Need to restart? → Just run ./bringupall.sh again

Files You Should Know

bringupall.sh → Main startup script
setup.sh → First-time configuration
/etc/cerberus/environment → Your secrets
/etc/cerberus/cerberus.ini → Main configuration


For full technical details, see README.md in the same directory.
Made for the mainframe hobbyist community.
EOF

