module github.com/n2nhu/cerberus-tunnel

go 1.21

require golang.ngrok.com/ngrok/v2 v2.1.1

require (
	github.com/jpillora/backoff v1.0.0 // indirect
	go.uber.org/multierr v1.11.0 // indirect
	golang.ngrok.com/muxado/v2 v2.0.1 // indirect
	golang.org/x/net v0.30.0 // indirect
	google.golang.org/protobuf v1.35.1 // indirect
)
