# cerberus-tunnel

Embedded ngrok TCP tunnel for the Cerberus Gate. Uses
[golang.ngrok.com/ngrok/v2](https://pkg.go.dev/golang.ngrok.com/ngrok/v2)
to hold a public TCP endpoint at a reserved ngrok address and forward
traffic to a local upstream (typically `proxy3270` on `127.0.0.1:3270`).

## Why this exists

The official ngrok agent doesn't ship an s390x binary. The ngrok-go SDK
is open source and pure Go, so it cross-compiles to any platform Go
supports — including IBM Z. This binary is the missing piece that
lets the entire Cerberus gatekeeper run on the mainframe Linux.

## Build

Native (run on the s390x host itself):

```bash
go build -o cerberus-tunnel
```

Cross-compile from amd64:

```bash
GOOS=linux GOARCH=s390x go build -o cerberus-tunnel-s390x
```

Verify on the target box:

```bash
file ./cerberus-tunnel-s390x
# ELF 64-bit MSB executable, IBM S/390 ...
```

## Run

```bash
export NGROK_AUTHTOKEN=2abc...your_token
./cerberus-tunnel --upstream 127.0.0.1:3270 \
                  --remote-url tcp://1.tcp.ngrok.io:26640
```

The `--remote-url` argument is your reserved TCP address from the ngrok
dashboard. Omit it for an ephemeral random URL during testing.

Use `--json-status` to have the binary emit one JSON line on stdout when
the tunnel is up — Cerberus reads this to learn the public URL.

## Signal handling

`SIGTERM` and `SIGINT` cleanly tear down the tunnel. The ngrok edge
endpoint disappears when the process exits, so when Cerberus has zero
authorized sessions and kills this process, **the public TCP endpoint
literally does not exist**.
