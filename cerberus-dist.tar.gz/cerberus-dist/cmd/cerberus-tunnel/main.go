// cerberus-tunnel — embedded ngrok TCP tunnel.
//
// Uses golang.ngrok.com/ngrok/v2 to hold a TCP endpoint at a reserved
// ngrok address (e.g. tcp://1.tcp.ngrok.io:26640) and forward all traffic
// to a local upstream (e.g. 127.0.0.1:3270, the proxy3270 turret).
//
// Runs as a Cerberus-managed subprocess. SIGTERM cleanly tears down the
// tunnel; the ngrok edge endpoint goes away with the process, so when no
// authorized sessions exist, no public TCP endpoint exists either.
//
// Build native:
//   cd cmd/cerberus-tunnel && go build -o cerberus-tunnel
// Build for s390x from amd64:
//   GOOS=linux GOARCH=s390x go build -o cerberus-tunnel-s390x
//
// Environment:
//   NGROK_AUTHTOKEN  — required, picked up by ngrok-go automatically
//
// Usage:
//   cerberus-tunnel --upstream 127.0.0.1:3270 --remote-url tcp://1.tcp.ngrok.io:26640
//   cerberus-tunnel --upstream 127.0.0.1:3270   (ephemeral random TCP URL)
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"

	"strings"

	"syscall"

	"golang.ngrok.com/ngrok/v2"
)

type readyMsg struct {
	URL      string `json:"url"`
	Upstream string `json:"upstream"`
}

func main() {
	upstream := flag.String("upstream", "127.0.0.1:3270",
		"Local TCP address to forward public traffic to")
	remoteURL := flag.String("remote-url", "tcp://",
		`Public ngrok URL to bind. Use "tcp://" for ephemeral, or `+
			`"tcp://1.tcp.ngrok.io:26640" for a reserved address.`)
	jsonStatus := flag.Bool("json-status", false,
		"Emit a single JSON line on stdout when the tunnel is up (for parent process to parse)")
	flag.Parse()

	if os.Getenv("NGROK_AUTHTOKEN") == "" {
		log.Fatal("NGROK_AUTHTOKEN must be set in the environment")
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Translate SIGTERM/SIGINT into context cancellation — ngrok-go tears
	// the tunnel down cleanly when the context is canceled.
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGTERM, syscall.SIGINT)
	go func() {
		s := <-sigCh
		log.Printf("received signal: %v, shutting down tunnel", s)
		cancel()
	}()

	// ngrok.Forward handles both sides of the proxy for us: it opens the
	// public endpoint AND dials the upstream for each accepted connection.
	// Returns an EndpointForwarder that runs until ctx is canceled.
	upstreamURL := "tcp://" + *upstream

	if strings.HasPrefix(*remoteURL, "https://") || strings.HasPrefix(*remoteURL, "http://") {

		upstreamURL = "http://" + *upstream

	}

	fwd, err := ngrok.Forward(ctx,

		ngrok.WithUpstream(upstreamURL),

		ngrok.WithURL(*remoteURL),

	)
	if err != nil {
		log.Fatalf("ngrok.Forward failed: %v", err)
	}
	defer fwd.CloseWithContext(context.Background())

	publicURL := fwd.URL()
	log.Printf("tunnel established: %s -> %s", publicURL, *upstream)

	if *jsonStatus {
		// One-line JSON status so the Python parent can read it
		_ = json.NewEncoder(os.Stdout).Encode(readyMsg{
			URL:      fmt.Sprintf("%v", publicURL),
			Upstream: *upstream,
		})
	}

	// Block until the context is canceled (signal received) or the
	// forwarder ends on its own.
	<-fwd.Done()
	log.Println("tunnel closed")
}
